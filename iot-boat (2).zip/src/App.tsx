/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Anchor, 
  Camera, 
  Fish, 
  Award, 
  User as UserIcon, 
  LogOut, 
  X, 
  Send, 
  Sparkles,
  Cloud,
  Sun,
  Moon,
  Waves
} from 'lucide-react';
import { auth, db, signIn, logout } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDoc,
  limit,
  getDocFromServer
} from 'firebase/firestore';
import { GoogleGenAI } from '@google/genai';

// --- Error Handling ---

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      let message = "Đã có lỗi xảy ra. Vui lòng thử lại sau.";
      try {
        const errInfo = JSON.parse(this.state.error?.message || '{}');
        if (errInfo.error?.includes('permission-denied')) {
          message = "Bạn không có quyền thực hiện thao tác này. Vui lòng đăng nhập.";
        }
      } catch {
        // Not a JSON error
      }

      return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <GlassPanel className="p-8 max-w-md w-full text-center space-y-4">
            <X className="w-16 h-16 text-red-400 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Ối! Có lỗi rồi</h2>
            <p className="text-white/80">{message}</p>
            <button 
              onClick={() => window.location.reload()}
              className="px-6 py-2 bg-white/20 hover:bg-white/30 text-white rounded-full transition-colors"
            >
              Tải lại trang
            </button>
          </GlassPanel>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Constants & Types ---
const GENAI_API_KEY = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({ apiKey: GENAI_API_KEY });

interface Catch {
  id?: string;
  userId: string;
  species: string;
  name: string;
  photoURL: string;
  timestamp: string;
  description: string;
}

interface Fisherman {
  uid: string;
  displayName: string;
  photoURL: string;
  isHonorary: boolean;
}

// --- Helper Components ---

const GlassPanel = ({ children, className = "", onClick }: { children: React.ReactNode, className?: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className={`backdrop-blur-[15px] bg-white/25 border border-white/30 rounded-[24px] shadow-[0_8px_32px_rgba(0,0,0,0.1)] ${className} ${onClick ? 'cursor-pointer' : ''}`}
  >
    {children}
  </div>
);

// --- Main App Component ---

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

function AppContent() {
  const [user, setUser] = useState<User | null>({ uid: 'anonymous-fisher', displayName: 'Ngư dân ẩn danh' } as User);
  const [catches, setCatches] = useState<Catch[]>([]);
  const [honoraryFishermen, setHonoraryFishermen] = useState<Fisherman[]>([]);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [isFishing, setIsFishing] = useState(false);
  const [fishingResult, setFishingResult] = useState<Catch | null>(null);
  const [timeOfDay, setTimeOfDay] = useState<'morning' | 'afternoon' | 'night'>('morning');
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Time of Day Logic
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 12) setTimeOfDay('morning');
    else if (hour >= 12 && hour < 19) setTimeOfDay('afternoon');
    else setTimeOfDay('night');
  }, []);

  // Firebase Auth & Data
  useEffect(() => {
    const qCatches = query(collection(db, 'catches'), orderBy('timestamp', 'desc'), limit(20));
    const unsubscribeCatches = onSnapshot(qCatches, (snapshot) => {
      setCatches(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Catch)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'catches');
    });

    const qFishermen = query(collection(db, 'users'), limit(4));
    const unsubscribeFishermen = onSnapshot(qFishermen, (snapshot) => {
      setHonoraryFishermen(snapshot.docs.map(doc => doc.data() as Fisherman));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    return () => {
      unsubscribeCatches();
      unsubscribeFishermen();
    };
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Creature Generation Logic
  const generateCreature = async (name: string, type: string) => {
    if (!user) return;
    setIsGenerating(true);
    try {
      const prompt = `Hãy mô tả một sinh vật biển huyền thoại tên là "${name}", thuộc loài "${type}". Mô tả ngắn gọn, thơ mộng bằng tiếng Việt.`;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      const description = response.text || '';

      // Generate Image
      let photoURL = `https://picsum.photos/seed/${name}${type}/400/300`;
      try {
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-image-preview',
          contents: {
            parts: [{ text: `A hyper-detailed, masterpiece 2.5D isometric Animal Crossing style illustration of a legendary sea creature: ${name}, a ${type}. Volumetric lighting, soft shadows, vibrant colors, dreamy cinematic atmosphere, 8k resolution, highly detailed textures.` }]
          },
          config: {
            imageConfig: { aspectRatio: "1:1", imageSize: "1K" }
          }
        });
        
        for (const part of imageResponse.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) {
            photoURL = `data:image/png;base64,${part.inlineData.data}`;
            break;
          }
        }
      } catch (imgError) {
        console.error("Image Gen Error:", imgError);
      }

      const newCatch: Catch = {
        userId: user.uid,
        species: type,
        name: name,
        photoURL: photoURL,
        timestamp: new Date().toISOString(),
        description: description
      };

      await addDoc(collection(db, 'catches'), newCatch);
      setFishingResult(newCatch);
      setActiveModal('fishing-result');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'catches');
    } finally {
      setIsGenerating(false);
    }
  };
  // Fishing Logic
  const startFishing = () => {
    if (!user) {
      alert("Vui lòng đăng nhập để thả câu!");
      return;
    }
    setIsFishing(true);
    setTimeout(async () => {
      // Simulate catch
      const speciesList = ["Cá Chép Vàng", "Tôm Hùm Xanh", "Cua Hoàng Đế", "Cá Rồng"];
      const species = speciesList[Math.floor(Math.random() * speciesList.length)];
      const newCatch: Catch = {
        userId: user.uid,
        species: species,
        name: `${species} của ${user.displayName}`,
        photoURL: `https://picsum.photos/seed/${species}/400/300`,
        timestamp: new Date().toISOString(),
        description: `Một sinh vật tuyệt đẹp được bắt tại vùng biển IOT.`
      };

      await addDoc(collection(db, 'catches'), newCatch);
      setFishingResult(newCatch);
      setIsFishing(false);
      setActiveModal('fishing-result');
    }, 5000);
  };

  // --- Styles ---
  const themeStyles = {
    morning: "from-[#FF9A8B] to-[#F7D794]",
    afternoon: "from-[#FF9A8B] to-[#FF6A88]",
    night: "from-[#1E3799] via-[#0D1B4D] to-[#050A1F]"
  };

  return (
    <div className={`relative w-full h-screen overflow-hidden bg-gradient-to-b ${themeStyles[timeOfDay]} font-['Quicksand']`}>
      
      {/* 1. SKY LAYER */}
      <div className="absolute inset-0 pointer-events-none">
        {timeOfDay === 'night' ? (
          <div className="absolute inset-0">
            {[...Array(150)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-white rounded-full"
                style={{
                  top: `${Math.random() * 70}%`,
                  left: `${Math.random() * 100}%`,
                }}
                animate={{ 
                  opacity: [0.1, 1, 0.1],
                  scale: [1, 1.5, 1]
                }}
                transition={{ duration: 2 + Math.random() * 5, repeat: Infinity }}
              />
            ))}
            <motion.div 
              className="absolute top-10 right-20 w-32 h-32 rounded-full bg-yellow-50 shadow-[0_0_100px_rgba(255,255,255,0.4)]"
              initial={{ y: -100 }}
              animate={{ y: 0 }}
            >
              <div className="absolute inset-0 rounded-full shadow-[inset_-15px_-15px_30px_rgba(0,0,0,0.1)]" />
              <div className="absolute top-8 left-8 w-4 h-4 bg-gray-200/30 rounded-full blur-sm" />
            </motion.div>
          </div>
        ) : (
          <motion.div 
            className="absolute top-20 right-32 w-40 h-40 rounded-full bg-gradient-to-br from-[#FFD32D] via-[#F0932B] to-[#E67E22] shadow-[0_0_120px_rgba(240,147,43,0.5)]"
            animate={{ y: timeOfDay === 'afternoon' ? 250 : 0 }}
            transition={{ duration: 2 }}
          >
            <div className="absolute inset-0 rounded-full shadow-[inset_-20px_-20px_40px_rgba(0,0,0,0.2)]" />
            <div className="absolute top-10 left-10 w-10 h-10 bg-white/20 rounded-full blur-md" />
          </motion.div>
        )}
        
        {/* Detailed Clouds with Specific Shapes */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute pointer-events-none"
            style={{
              top: `${10 + i * 12}%`,
              left: `${-10 + i * 25}%`,
            }}
            animate={{ x: [0, 50, 0] }}
            transition={{ duration: 40 + i * 15, repeat: Infinity, ease: "linear" }}
          >
            <div className="relative">
              {/* Main cloud body */}
              <div className="w-48 h-16 bg-white/90 rounded-full blur-[2px] shadow-lg" />
              {/* Cloud bumps for specific shape */}
              <div className="absolute -top-8 left-8 w-20 h-20 bg-white/90 rounded-full blur-[2px]" />
              <div className="absolute -top-4 left-20 w-16 h-16 bg-white/90 rounded-full blur-[2px]" />
              <div className="absolute -top-6 left-4 w-12 h-12 bg-white/90 rounded-full blur-[2px]" />
            </div>
          </motion.div>
        ))}
      </div>

      {/* 2. 3D WATER PLANE */}
      <div className="absolute bottom-0 w-full h-[40%] perspective-[1200px]">
        <div 
          className="absolute inset-0 origin-bottom transform rotateX(60deg) bg-[#1E3799]/60 overflow-hidden border-t-8 border-white/30"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Flowing Water Effect */}
          <motion.div 
            className="absolute inset-0 opacity-40"
            animate={{ backgroundPosition: ['0% 0%', '100% 100%'] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            style={{ 
              backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }}
          />

          {/* Dynamic Rolling Waves - Rougher Sea */}
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-[300%] h-32 bg-gradient-to-b from-white/20 to-transparent"
              style={{ top: `${i * 10}%`, left: '-100%' }}
              animate={{ 
                x: ['-5%', '5%'],
                y: [0, 35, 0], // Increased vertical movement for rougher sea
                opacity: [0.1, 0.4, 0.1]
              }}
              transition={{ 
                duration: 2 + i * 0.5, // Faster but more chaotic
                repeat: Infinity, 
                ease: "easeInOut",
                delay: i * 0.3
              }}
            />
          ))}

          {/* Splash particles around the boat area */}
          {[...Array(15)].map((_, i) => (
            <motion.div
              key={`splash-${i}`}
              className="absolute w-4 h-4 bg-white/40 rounded-full blur-sm"
              style={{ 
                top: '50%', 
                left: `${40 + Math.random() * 20}%`,
                zIndex: 20
              }}
              animate={{ 
                y: [0, -60, 0],
                x: [0, (Math.random() - 0.5) * 100, 0],
                scale: [0, 1.5, 0],
                opacity: [0, 0.8, 0]
              }}
              transition={{ 
                duration: 1 + Math.random(), 
                repeat: Infinity, 
                delay: Math.random() * 2 
              }}
            />
          ))}

          {/* Swirling Ripples around the center - More intense */}
          <motion.div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] border-[25px] border-white/15 rounded-full blur-3xl"
            animate={{ rotate: 360, scale: [1, 1.2, 1] }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          />

          {/* Bioluminescent Plankton (Night) */}
          {timeOfDay === 'night' && [...Array(30)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-cyan-400 rounded-full blur-[2px]"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
              }}
              animate={{ opacity: [0, 0.8, 0], scale: [0.5, 1, 0.5] }}
              transition={{ duration: 3 + Math.random() * 2, repeat: Infinity }}
            />
          ))}
        </div>
      </div>

      {/* 3. (REMOVED ISLAND) */}

      {/* 4. FLOATING LIFE & OBJECTS (On the water) */}
      <div className="absolute bottom-0 w-full h-[40%] pointer-events-none z-15">
        {[...Array(20)].map((_, i) => {
          const type = i % 5; // 0: Fish, 1: Crab, 2: Coconut, 3: Shrimp, 4: Seagull
          const startLeft = Math.random() < 0.5 ? -10 : 110;
          const endLeft = startLeft === -10 ? 110 : -10;
          const bottom = 5 + Math.random() * 90;
          const duration = 25 + Math.random() * 40; // Significantly slowed down
          const delay = Math.random() * 20;
          
          return (
            <motion.div
              key={i}
              className="absolute"
              style={{ bottom: `${bottom}%` }}
              initial={{ left: `${startLeft}%`, opacity: 0 }}
              animate={{ 
                left: `${endLeft}%`,
                opacity: [0, 1, 1, 0],
                y: type === 4 ? [-200, -280, -200] : [0, -20, 0],
                rotate: type === 2 ? [0, 720] : type === 4 ? [-15, 15, -15] : [0, 0],
                scaleX: startLeft < endLeft ? 1 : -1
              }}
              transition={{ 
                duration: duration, 
                repeat: Infinity, 
                delay,
                ease: "linear" 
              }}
            >
              {type === 0 && <Fish size={28} className="text-cyan-200 opacity-90 drop-shadow-[0_5px_10px_rgba(0,0,0,0.3)]" />}
              {type === 1 && <div className="w-6 h-5 bg-red-500 rounded-full relative shadow-lg"><div className="absolute -left-2 top-1 w-4 h-2 bg-red-500 rotate-45" /><div className="absolute -right-2 top-1 w-4 h-2 bg-red-500 -rotate-45" /></div>}
              {type === 2 && <div className="w-8 h-8 bg-[#3e2723] rounded-full shadow-2xl border border-black/30"><div className="absolute top-2 left-2 w-2 h-2 bg-white/40 rounded-full" /></div>}
              {type === 3 && <div className="w-6 h-3 bg-orange-400 rounded-full opacity-80 shadow-md" />}
              {type === 4 && (
                <div className="flex gap-1 scale-150">
                  <motion.div 
                    className="w-5 h-1 bg-white rounded-full origin-right"
                    animate={{ rotate: [-20, 20, -20] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                  <motion.div 
                    className="w-5 h-1 bg-white rounded-full origin-left"
                    animate={{ rotate: [20, -20, 20] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* 5. THE IOT BOAT (Isometric SVG) */}
      <motion.div 
        className="absolute bottom-[10%] left-1/2 -translate-x-1/2 w-[400px] z-20"
        animate={{ 
          y: [-25, 35, -25], // Increased vertical movement for wave interaction
          rotateZ: [4, -5, 4], // More rocking
          rotateX: [8, -4, 8],
          scale: [1, 1.05, 1] // Slight pulsing with waves
        }}
        transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        <svg viewBox="0 0 400 300" className="w-full filter drop-shadow-[0_40px_20px_rgba(0,0,0,0.3)]">
          <defs>
            <linearGradient id="hullGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#A0522D" />
              <stop offset="100%" stopColor="#5D4037" />
            </linearGradient>
            <linearGradient id="roofGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#43A047" />
              <stop offset="100%" stopColor="#1B5E20" />
            </linearGradient>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="3" />
              <feOffset dx="2" dy="2" result="offsetblur" />
              <feComponentTransfer>
                <feFuncA type="linear" slope="0.5" />
              </feComponentTransfer>
              <feMerge>
                <feMergeNode />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Hull - Rounder & Cuter Isometric Boat */}
          <ellipse cx="200" cy="160" rx="150" ry="60" fill="#5d4037" /> {/* Bottom Shadow */}
          <path 
            d="M50 150 C 50 200, 350 200, 350 150 C 350 100, 50 100, 50 150" 
            fill="url(#hullGrad)" 
            stroke="#3e2723" 
            strokeWidth="4" 
          /> {/* Main Deck Body */}
          
          {/* Cabin - Rounder Isometric Box */}
          <g filter="url(#shadow)">
            <rect x="150" y="80" width="100" height="70" rx="20" fill="#EFEBE9" /> {/* Main Cabin Body */}
            <rect x="150" y="70" width="100" height="20" rx="10" fill="url(#roofGrad)" /> {/* Roof */}
            
            {/* Windows - Rounder */}
            <circle cx="185" cy="115" r="12" fill="#81D4FA" stroke="#455A64" strokeWidth="2" />
            <circle cx="215" cy="115" r="12" fill="#81D4FA" stroke="#455A64" strokeWidth="2" />
          </g>

          {/* Mast & Flag */}
          <line x1="200" y1="100" x2="200" y2="20" stroke="#5d4037" strokeWidth="6" strokeLinecap="round" />
          <motion.path 
            d="M200 30 Q 230 20 260 30 L 260 60 Q 230 50 200 60 Z" 
            fill="#ff5252"
            animate={{ d: [
              "M200 30 Q 230 20 260 30 L 260 60 Q 230 50 200 60 Z",
              "M200 30 Q 230 40 260 30 L 260 60 Q 230 70 200 60 Z",
              "M200 30 Q 230 20 260 30 L 260 60 Q 230 50 200 60 Z"
            ]}}
            transition={{ duration: 2, repeat: Infinity }}
          />

          {/* Lantern */}
          <g transform="translate(140, 140)">
            <motion.g
              animate={{ rotateX: [15, -15, 15] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              <rect x="-5" y="0" width="10" height="15" fill="#ffd600" rx="2" />
              <circle cx="0" cy="7" r="3" fill="white" className="animate-pulse" />
            </motion.g>
          </g>

          {/* Deck Clutter */}
          <g transform="translate(280, 160)">
            <path d="M0 0 L20 10 L20 30 L0 20 Z" fill="#795548" /> {/* Barrel Side */}
            <ellipse cx="10" cy="0" rx="10" ry="5" fill="#a1887f" /> {/* Barrel Top */}
          </g>
        </svg>

        {/* Fishing Line (Visible when fishing) */}
        {isFishing && (
          <motion.div 
            className="absolute top-[20%] left-1/2 w-[2px] bg-white/50 origin-top"
            initial={{ height: 0 }}
            animate={{ height: 300 }}
            transition={{ duration: 1 }}
          >
            <motion.div 
              className="absolute bottom-0 left-[-5px] w-3 h-3 bg-red-500 rounded-full"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          </motion.div>
        )}
      </motion.div>

      {/* 5. UI OVERLAYS */}
      
      {/* Top Left: Status Bar */}
      <div className="absolute top-8 left-8 z-50 flex flex-col gap-4">
        <GlassPanel className="flex items-center gap-4 p-4 pr-6">
          <div className="w-3 h-3 bg-[#55E6C1] rounded-full shadow-[0_0_10px_#55E6C1]" />
          <div className="flex items-center gap-3">
            <span className="text-white font-bold">IOT Boat v2.5</span>
            <div className="w-[1px] h-5 bg-white/30" />
            <span className="text-white/80 text-xs">Trạng thái: Đang trôi tự do</span>
          </div>
        </GlassPanel>

        {/* Stat Card */}
        <GlassPanel className="p-5 w-64 space-y-3">
          <div className="flex justify-between text-white/90 text-sm">
            <span>Nhiệt độ nước</span>
            <span className="font-bold">24°C</span>
          </div>
          <div className="flex justify-between text-white/90 text-sm">
            <span>Độ mặn</span>
            <span className="font-bold">3.2%</span>
          </div>
          <div className="flex justify-between text-white/90 text-sm">
            <span>Tốc độ gió</span>
            <span className="font-bold">12 km/h</span>
          </div>
          <div className="pt-2">
            <div className="h-1 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-[#FFD32D] w-[65%] rounded-full" />
            </div>
            <p className="text-[10px] text-white/60 mt-1">Năng lượng mặt trời: 65%</p>
          </div>
        </GlassPanel>
      </div>

      {/* Top Right: Music & Settings */}
      <div className="absolute top-6 right-6 z-50 flex flex-col gap-4">
        <GlassPanel className="p-3 cursor-pointer hover:scale-110 transition-transform" onClick={() => audioRef.current?.paused ? audioRef.current?.play() : audioRef.current?.pause()}>
          <Waves className="text-white" />
        </GlassPanel>
        <audio ref={audioRef} loop src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" />
      </div>

      {/* Bottom Navigation */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-50">
        <GlassPanel className="flex items-center gap-6 p-4 px-8">
          <NavButton icon={<Camera size={24} />} label="Tải ảnh" onClick={() => setActiveModal('upload')} />
          <NavButton 
            icon={<Fish size={24} className={isFishing ? "animate-bounce" : ""} />} 
            label="Thả câu" 
            onClick={startFishing}
            disabled={isFishing}
          />
          <NavButton icon={<Award size={24} />} label="Tôn vinh" onClick={() => setActiveModal('honorary')} />
        </GlassPanel>
      </div>

      {/* 6. MODALS */}
      <AnimatePresence>
        {activeModal && (
          <motion.div 
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div 
              className="relative w-full max-w-2xl"
              initial={{ scale: 0.8, rotateX: 20, y: 50 }}
              animate={{ scale: 1, rotateX: 0, y: 0 }}
              exit={{ scale: 0.8, rotateX: 20, y: 50 }}
              transition={{ type: "spring", damping: 15 }}
            >
              <GlassPanel className="p-8 bg-white/90 border-white">
                <button 
                  onClick={() => setActiveModal(null)}
                  className="absolute top-4 right-4 p-2 hover:bg-black/10 rounded-full transition-colors"
                >
                  <X size={24} />
                </button>

                {activeModal === 'upload' && (
                  <div className="space-y-6">
                    <h2 className="text-3xl font-bold text-blue-900">Tạo sinh vật nước ngọt</h2>
                    <form onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      generateCreature(formData.get('name') as string, formData.get('type') as string);
                    }} className="space-y-4">
                      <input name="name" required type="text" placeholder="Tên sinh vật..." className="w-full p-4 rounded-xl bg-blue-50 border-2 border-blue-100 focus:border-blue-400 outline-none" />
                      <select name="type" className="w-full p-4 rounded-xl bg-blue-50 border-2 border-blue-100 outline-none">
                        <option>Cá</option>
                        <option>Tôm</option>
                        <option>Cua</option>
                        <option>Rùa</option>
                      </select>
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-blue-200 rounded-2xl p-10 text-center hover:bg-blue-50 transition-colors cursor-pointer overflow-hidden relative"
                      >
                        {uploadedImage ? (
                          <img src={uploadedImage} className="absolute inset-0 w-full h-full object-cover" alt="Uploaded" />
                        ) : (
                          <>
                            <Camera size={48} className="mx-auto text-blue-300 mb-2" />
                            <p className="text-blue-400">Tải ảnh khuôn mặt của bạn</p>
                          </>
                        )}
                        <input 
                          type="file" 
                          ref={fileInputRef} 
                          onChange={handleFileUpload} 
                          className="hidden" 
                          accept="image/*"
                        />
                      </div>
                      <button type="submit" disabled={isGenerating} className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg disabled:opacity-50">
                        {isGenerating ? "Đang tạo..." : "Tạo sinh vật ngay!"}
                      </button>
                    </form>
                  </div>
                )}

                {activeModal === 'fishing-result' && fishingResult && (
                  <div className="text-center space-y-6">
                    <h2 className="text-3xl font-bold text-blue-900">Chúc mừng!</h2>
                    <div className="relative w-64 h-64 mx-auto rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
                      <img src={fishingResult.photoURL} alt="Catch" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                        <p className="text-white font-bold">{fishingResult.species}</p>
                      </div>
                    </div>
                    <p className="text-blue-800 text-lg italic">"{fishingResult.description}"</p>
                    <button 
                      onClick={() => setActiveModal(null)}
                      className="px-8 py-3 bg-blue-600 text-white rounded-full font-bold hover:bg-blue-700 transition-all"
                    >
                      Tuyệt vời!
                    </button>
                  </div>
                )}

                {activeModal === 'honorary' && (
                  <div className="space-y-6">
                    <h2 className="text-3xl font-bold text-blue-900">Ngư dân danh dự</h2>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      {honoraryFishermen.map((f, i) => (
                        <div key={i} className="text-center space-y-2 group">
                          <div className="relative w-24 h-24 mx-auto">
                            <img src={f.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`} alt={f.displayName} className="w-full h-full rounded-full border-4 border-yellow-400 shadow-lg group-hover:scale-110 transition-transform" />
                            <Award className="absolute -bottom-2 -right-2 text-yellow-500 fill-yellow-500" size={24} />
                          </div>
                          <p className="font-bold text-blue-900 text-sm truncate">{f.displayName}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </GlassPanel>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 7. TOASTS & NOTIFICATIONS */}
      {isFishing && (
        <motion.div 
          className="fixed top-10 left-1/2 -translate-x-1/2 z-[200]"
          initial={{ y: -100 }}
          animate={{ y: 0 }}
        >
          <GlassPanel className="px-8 py-4 bg-blue-600 text-white font-bold flex items-center gap-3">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Đang thả câu... Đừng làm cá sợ!
          </GlassPanel>
        </motion.div>
      )}

    </div>
  );
}

function NavButton({ icon, label, onClick, disabled = false }: { icon: React.ReactNode, label: string, onClick: () => void, disabled?: boolean }) {
  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`flex flex-col items-center gap-1 group transition-all transform hover:scale-110 active:scale-95 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className="p-3 rounded-xl bg-white/10 group-hover:bg-white/30 transition-colors text-white shadow-inner">
        {icon}
      </div>
      <span className="text-white text-[10px] font-bold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">
        {label}
      </span>
    </button>
  );
}
